<?php
date_default_timezone_set('Asia/Makassar');
echo date('H:i:s', 1484800816);